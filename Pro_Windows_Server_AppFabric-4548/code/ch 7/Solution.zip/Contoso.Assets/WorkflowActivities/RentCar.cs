﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using BusinessEntities;
using System.ServiceModel;
using CarRental.WCF;

namespace WorkflowActivities
{
    public class RentCar : CodeActivity
    {
        public InArgument<Claim> Entity { get; set; }
        public OutArgument<string> ConfirmationStatus { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Claim claim = Entity.Get<Claim>(context);

            //Check if the destination endpoint has been announced (discovered) yet
            if (String.IsNullOrEmpty(claim.RentalCar))
            {
                ConfirmationStatus.Set(context, "No rental car");
                return;
            }

            //Create the target service client
            ChannelFactory<ICarRental> factory = new ChannelFactory<ICarRental>(new BasicHttpBinding(), 
                                                            claim.RentalCar);
            ICarRental client = factory.CreateChannel();

            //Call the Car Rental Service
            string status = client.FindRentalCar(claim.ClaimId);

            factory.Close();

            //return  a new status of the processed claim
            ConfirmationStatus.Set(context, status);

        }
    }
}
