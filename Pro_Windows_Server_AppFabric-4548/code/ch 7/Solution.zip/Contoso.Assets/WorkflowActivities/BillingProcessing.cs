﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.ServiceModel.Discovery;
using Billing.WCF;
using System.ServiceModel;
using BusinessEntities;

namespace WorkflowActivities
{
    public class BillingProcessing : CodeActivity
    {
        public InArgument<Claim> Entity { get; set; }
        public OutArgument<string> Status { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Claim claim = Entity.Get(context);
            Status.Set(context, "");

            //Create DiscoveryClient
            DiscoveryClient discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());

            //Create the search criteria for the specified scope
            FindCriteria findCriteria = new FindCriteria(typeof(IBilling));

            //Find BillingService endpoint
            FindResponse findResponse = discoveryClient.Find(findCriteria);

            if (findResponse.Endpoints.Count == 0)
            {
                Status.Set(context, "No Billing Service endpoints were found");
                return;
            }

            //Pick the first discovered endpoint
            EndpointAddress address = findResponse.Endpoints[0].Address;

            //Create the target service client
            ChannelFactory<IBilling> factory = new ChannelFactory<IBilling>(new BasicHttpBinding(), address);
            IBilling client = factory.CreateChannel();

            //Call the Billing Service
            string status = client.ProcessClaim(claim.ClaimId, findResponse.Endpoints.Count, address.Uri.AbsoluteUri);
            
            factory.Close();

            //return  a new status of the processed claim
            Status.Set(context, status);
        }
    }
}
