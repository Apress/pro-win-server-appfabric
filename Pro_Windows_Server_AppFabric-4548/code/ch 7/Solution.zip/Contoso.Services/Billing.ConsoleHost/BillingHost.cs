﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Billing.ConsoleHost
{
    class BillingHost
    {
        static string address = "http://localhost:8000/BillingService";

        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                throw new Exception("Usage: Billing.ConsoleHost.exe [argument]\n\nWhere argument: (A - for AdHoc Service Discovery; M - for Managed Service Discovery)");
            }

            if (args[0] == "A")
            {
                AdHocServiceDiscovery adHocDiscoveryHost = new AdHocServiceDiscovery(address);
                adHocDiscoveryHost.Host();
            }
            else if (args[0] == "M")
            {
                ManagedServiceDiscovery mngDiscoveryHost = new ManagedServiceDiscovery(address);
                mngDiscoveryHost.Host();
            }
        }
    }
}
