﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CarRental.WCF
{
    public class CarRentalService : ICarRental
    {
        public string FindRentalCar(int claimId)
        {
            Console.WriteLine("Rental car has been successfully reserved for the claim ID: {0}.", claimId);
            return "A rental car has been reserved.";
        }
    }
}
