﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Appraisal.ConsoleHost
{
    class AppraisalHost
    {
        static Uri httpAddress = new Uri("http://localhost:9000/AppraisalService");
        static Uri tcpAddress = new Uri("net.tcp://localhost:9001/AppraisalService");

        static void Main(string[] args)
        {
            DefaultEndPoint defaultEndPointHost = new DefaultEndPoint(new Uri[] { httpAddress, tcpAddress });
            defaultEndPointHost.Host();
        }
    }
}
