﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BusinessEntities;

namespace Billing.WCF
{
    public class BillingService : IBilling
    {
        ClaimRepository claimRepository = new ClaimRepository();

        public string ProcessClaim(int claimId, int endpoints, string address)
        {
            Console.WriteLine("{0}: Discovered {1} endpoints.", DateTime.Now.ToShortTimeString(), endpoints);
            Console.WriteLine("{0}: Using the endpoint address at: {1}", DateTime.Now.ToShortTimeString(), address);

            Claim claim = claimRepository.GetClaim(claimId);
            if (claim != null)
                return "Complete";
            else
                return "Error";
        }
    }
}
