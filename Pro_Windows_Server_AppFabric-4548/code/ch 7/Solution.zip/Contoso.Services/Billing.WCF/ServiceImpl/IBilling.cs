﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Billing.WCF
{
    [ServiceContract]
    public interface IBilling
    {
        [OperationContract]
        string ProcessClaim(int claimId, int endpoints, string address);
    }
}
