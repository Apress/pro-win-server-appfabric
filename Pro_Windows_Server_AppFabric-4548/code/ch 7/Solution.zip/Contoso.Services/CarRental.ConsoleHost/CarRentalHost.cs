﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarRental.ConsoleHost
{
    class CarRentalHost
    {
        static string address = "http://localhost:8888/CarRentalService";

        static void Main(string[] args)
        {
            ServiceAnnouncementHost svcAnnouncementHost = new ServiceAnnouncementHost(address);
            svcAnnouncementHost.Host();
        }
    }
}
