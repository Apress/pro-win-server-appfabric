﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Claims.Web.Models;
using Claims.Web.Helpers;

namespace Claims.Web.Controllers
{
    public class ClaimsController_Local : Controller
    {
        ClaimRepository claimRepository = new ClaimRepository();


        //
        // GET: /Claims/

        public ActionResult Index(int? page)
        {
            const int pageSize = 10;

            var claims = claimRepository.FindPendingClaims();
            var paginatedClaims = new PaginatedList<Claim>(claims, page ?? 0, pageSize);

            return View(paginatedClaims);
        }

        //
        // GET: /Claims/Details/5

        public ActionResult Details(int id)
        {
            Claim claim = claimRepository.GetClaim(id);

            if (claim == null)
                return View("NotFound");
            else
                return View(claim);
        }

        //
        // GET: /Claims/Edit/5
        [Authorize(Users="dannyg,stephenk")]
        public ActionResult Edit(int id)
        {
            Claim claim = claimRepository.GetClaim(id);
            
            return View(new ClaimFormViewModel(claim));
        }

        //
        // POST: /Claims/Edit/5

        [AcceptVerbs(HttpVerbs.Post), Authorize]
        public ActionResult Edit(int id, FormCollection collection)
        {
            //Retrieve existing claim
            Claim claim = claimRepository.GetClaim(id);

            //Retrieve existing claim
            Claim originalClaim = claim.Copy();

            try
            {
                //Update model
                UpdateModel(claim);
                UpdateModel(claim.Accidents);

                //Update Model components
                //claim.Accidents.FName = collection["FName"];
                //claim.Accidents.LName = collection["LName"];
                //claim.Accidents.Address = collection["Address"];
                //claim.Accidents.City = collection["City"];
                //claim.Accidents.State = (string)collection["State"];
                //claim.Accidents.Latitude = float.Parse(collection["Latitude"]);
                //claim.Accidents.Longitude = float.Parse(collection["Longitude"]);

                //Always update the date if the at least one field has been updated
                if (!claim.IsIdentical(originalClaim))
                {
                    claim.DateCreated = DateTime.Now;

                    //Persist changes back to database
                    claimRepository.Save();
                }


                //Perform HTTP redirect to details page for the saved Claim
                return RedirectToAction("Details", new { id = claim.ClaimId });
            }
            catch
            {
                ModelState.AddRuleViolations(claim.GetRuleViolations());
                return View(new ClaimFormViewModel(claim));
            }
        }
    }
}
