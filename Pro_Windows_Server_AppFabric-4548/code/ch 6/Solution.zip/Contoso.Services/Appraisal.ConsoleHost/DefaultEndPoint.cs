﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.ServiceModel.Description;
using Appraisal.WCF;

namespace Appraisal.ConsoleHost
{
    public class DefaultEndPoint
    {
        private List<Uri> baseAddresses;

        public DefaultEndPoint(Uri[] addresses) 
        {
            baseAddresses = new List<Uri>();
            foreach (var address in addresses)
                baseAddresses.Add(address);
        }

        public void Host()
        {
            ServiceHost host = new ServiceHost(typeof(AppraisalService), baseAddresses.ToArray<Uri>());

            //To enforce the explicit WCF binding
            //host.AddServiceEndpoint(typeof(IClaimInfo), new WSHttpBinding(), "");

            host.Open();
            foreach (var item in host.Description.Endpoints)
            {
                Console.WriteLine("Address: {0}\nBinding Name: {1}\nContract Name: {2}\n\n",
                    item.Address, item.Binding.Name, item.Contract.Name);
            }


            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();
            host.Close();

        }
    }
}
