﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Appraisal.WCF.ServiceImpl;
using Appraisal.WCF.DataContracts;

namespace Billing.WCF
{
    public class BillingService : IBilling
    {
        ClaimRepository claimRepository = new ClaimRepository();

        public string ProcessClaim(int claimId, int endpoints, string address)
        {
            Console.WriteLine("Discovered {0} endpoints.", endpoints);
            Console.WriteLine("Using the endpoint address at: {0}", address);

            Claim claim = claimRepository.GetClaim(claimId);
            if (claim != null)
                return "Complete";
            else
                return "Error";
        }
    }
}
