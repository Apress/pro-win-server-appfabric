﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Appraisal.WCF.DataContracts;

namespace Appraisal.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IClaimInfo
    {
        [OperationContract]
        List<Claim> FindAllClaims();

        [OperationContract]
        List<Claim> FindPendingClaims();

        [OperationContract]
        Claim GetLastClaim();

        [OperationContract]
        Claim GetClaim(int claimId);

        [OperationContract]
        void Save(Claim claim);

    }
}
