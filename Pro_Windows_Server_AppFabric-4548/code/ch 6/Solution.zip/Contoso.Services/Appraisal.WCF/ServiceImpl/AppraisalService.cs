﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Appraisal.WCF.DataContracts;
using Appraisal.WCF.ServiceImpl;

namespace Appraisal.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class AppraisalService : IClaimInfo
    {
        ClaimRepository claimRepository = new ClaimRepository();


        public List<Claim> FindAllClaims()
        {
            return claimRepository.FindAllClaims().ToList<Claim>();
        }


        public List<Claim> FindPendingClaims()
        {
            return claimRepository.FindPendingClaims().ToList<Claim>();
        }

        public Claim GetLastClaim()
        {
            return claimRepository.GetLastClaim();
        }

        public Claim GetClaim(int claimId)
        {
            return claimRepository.GetClaim(claimId);
        }


        public void Save(Claim claim)
        {
            Claim originalClaim = claimRepository.GetClaim(claim.ClaimId);

            //Update the claim
            originalClaim.AccidentId = originalClaim.AccidentId;
            originalClaim.Accidents.FName = claim.Accidents.FName;
            originalClaim.Accidents.LName = claim.Accidents.LName;
            originalClaim.Accidents.Address = claim.Accidents.Address;
            originalClaim.Accidents.City = claim.Accidents.City;
            originalClaim.Accidents.ContactPhone = claim.Accidents.ContactPhone;
            originalClaim.Accidents.State = claim.Accidents.State;
            originalClaim.Accidents.Zip = claim.Accidents.Zip;
            originalClaim.Accidents.Latitude = claim.Accidents.Latitude;
            originalClaim.Accidents.Longitude = claim.Accidents.Longitude;
            originalClaim.Description = claim.Description;
            originalClaim.DateCreated = claim.DateCreated;
            originalClaim.Status = claim.Status;
            originalClaim.RentalCar = claim.RentalCar;


            claimRepository.Save();
        }
    }
}
