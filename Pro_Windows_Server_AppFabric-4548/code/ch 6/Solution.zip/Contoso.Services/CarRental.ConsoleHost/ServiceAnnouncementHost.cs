﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.ServiceModel.Description;
using CarRental.WCF;

namespace CarRental.ConsoleHost
{
    public class ServiceAnnouncementHost
    {
        private Uri baseAddress;

        public ServiceAnnouncementHost(Uri address)
        {
            baseAddress = address;
        }

        public ServiceAnnouncementHost(string address)
        {
            baseAddress = new Uri(address);
        }

        public void Host()
        {
            ServiceHost host = new ServiceHost(typeof(CarRentalService), baseAddress);

            /// Commented out as this has been configured in the app.config file
            //// Announce the availability of the service over UDP multicast
            //ServiceDiscoveryBehavior serviceDiscoveryBehavior = new
            //ServiceDiscoveryBehavior();
            //serviceDiscoveryBehavior.AnnouncementEndpoints.Add(new
            //UdpAnnouncementEndpoint());

            //// Make the service discoverable over UDP multicast
            //host.Description.Behaviors.Add(serviceDiscoveryBehavior);  

            host.Open();

            foreach (var item in host.Description.Endpoints)
            {
                Console.WriteLine("Address: {0}\nBinding Name: {1}\nContract Name: {2}",
                    item.Address, item.Binding.Name, item.Contract.Name);
            }

            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();
            host.Close();

        }
    }
}
