﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.ServiceModel.Description;
using Billing.WCF;

namespace Billing.ConsoleHost
{
    public class AdHocServiceDiscovery
    {
        private Uri baseAddress;

        public AdHocServiceDiscovery(Uri address)
        {
            baseAddress = address;
        }

        public AdHocServiceDiscovery(string address)
        {
            baseAddress = new Uri(address);
        }

        public void Host()
        {
            ServiceHost host = new ServiceHost(typeof(BillingService), baseAddress);

            // Announce the availability of the service over UDP multicast
            UdpDiscoveryEndpoint adHocDiscovery = new UdpDiscoveryEndpoint();
            ServiceDiscoveryBehavior serviceDiscoveryBehavior = new ServiceDiscoveryBehavior();

            // Make the service discoverable over UDP multicast
            host.Description.Endpoints.Add(adHocDiscovery);
            host.Description.Behaviors.Add(serviceDiscoveryBehavior);


            host.Open();

            foreach (var item in host.Description.Endpoints)
            {
                Console.WriteLine("Address: {0}\nBinding Name: {1}\nContract Name: {2}",
                    item.Address, item.Binding.Name, item.Contract.Name);
            }

            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();
            host.Close();

        }
    }
}
