﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Discovery;
using System.ServiceModel.Description;
using Billing.WCF;

namespace Billing.ConsoleHost
{
    public class ManagedServiceDiscovery
    {
        private Uri baseAddress;
        private Uri announcementEndpointAddress = new Uri("net.tcp://localhost:9091/Announcement");


        public ManagedServiceDiscovery(string address)
        {
            baseAddress = new Uri(address + "/" + Guid.NewGuid().ToString());
        }

        public void Host()
        {
            ServiceHost host = new ServiceHost(typeof(BillingService), baseAddress);

            ServiceEndpoint netTcpEndpoint = host.AddServiceEndpoint(typeof(IBilling), 
                                                new NetTcpBinding(), string.Empty);

            // Create an announcement endpoint pointing to the hosted proxy service
            AnnouncementEndpoint announcementEndpoint = new AnnouncementEndpoint(
                    new NetTcpBinding(), new EndpointAddress(announcementEndpointAddress));
            ServiceDiscoveryBehavior serviceDiscoveryBehavior = new ServiceDiscoveryBehavior();

            serviceDiscoveryBehavior.AnnouncementEndpoints.Add(announcementEndpoint);
            host.Description.Behaviors.Add(serviceDiscoveryBehavior);

            host.Open();

            foreach (var item in host.Description.Endpoints)
            {
                Console.WriteLine("Address: {0}\nBinding Name: {1}\nContract Name: {2}",
                    item.Address, item.Binding.Name, item.Contract.Name);
            }

            Console.WriteLine("Press <Enter> to stop the service.");
            Console.ReadLine();
            host.Close();

        }
    }
}
